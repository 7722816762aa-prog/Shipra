package com.shipra.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ShipraReply(val say: String, val actions: List<JSONObject>)

class ShipraBrain(private val memory: MemoryStore) {

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    /** ब्लॉकिंग कॉल: IO थ्रेड पर चलाओ */
    fun chat(userText: String): ShipraReply {
        if (BuildConfig.API_KEY.isBlank()) {
            return ShipraReply("अरे, API key तो डाली ही नहीं तुमने। local.properties में डालो, फिर बात करना।", emptyList())
        }

        val system = Persona.build(memory.allFacts(), memory.search(userText))

        val msgs = JSONArray()
        memory.recentMessages(20).forEach { (role, content) ->
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        msgs.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject()
            .put("model", BuildConfig.MODEL)
            .put("max_tokens", 600)
            .put("system", system)
            .put("messages", msgs)

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", BuildConfig.API_KEY)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val raw = try {
            http.newCall(req).execute().use { resp ->
                val s = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return ShipraReply("सर्वर ने मना कर दिया, कोड ${resp.code}। अपनी key और model का नाम चेक करो।", emptyList())
                }
                JSONObject(s).getJSONArray("content").getJSONObject(0).getString("text")
            }
        } catch (e: IOException) {
            return ShipraReply("इंटरनेट नहीं चल रहा लगता है, कनेक्शन देखो।", emptyList())
        } catch (e: Exception) {
            return ShipraReply("कुछ गड़बड़ हो गई, फिर से बोलना।", emptyList())
        }

        val reply = parse(raw)
        // सफल बातचीत ही मेमोरी में जाती है (ताकि user/assistant का क्रम बना रहे)
        memory.addMessage("user", userText)
        memory.addMessage("assistant", reply.say)
        return reply
    }

    private fun parse(raw: String): ShipraReply {
        return try {
            val start = raw.indexOf('{')
            val end = raw.lastIndexOf('}')
            val obj = JSONObject(raw.substring(start, end + 1))

            obj.optJSONArray("remember")?.let { arr ->
                for (i in 0 until arr.length()) memory.addFact(arr.optString(i))
            }
            val actions = ArrayList<JSONObject>()
            obj.optJSONArray("actions")?.let { arr ->
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { actions.add(it) }
            }
            ShipraReply(obj.optString("say").ifBlank { "हम्म।" }, actions)
        } catch (e: Exception) {
            // मॉडल ने JSON नहीं दिया तो पूरा टेक्स्ट ही बोल दो
            ShipraReply(raw.trim(), emptyList())
        }
    }
}
