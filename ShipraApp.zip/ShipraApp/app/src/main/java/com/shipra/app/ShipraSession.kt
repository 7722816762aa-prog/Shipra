package com.shipra.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class UiState { IDLE, LISTENING, THINKING, SPEAKING }

/** सुनो → सोचो → बोलो → काम करो, यही पूरा लूप है */
class ShipraSession(private val ctx: Context, private val scope: CoroutineScope) {

    var state by mutableStateOf(UiState.IDLE); private set
    var heard by mutableStateOf(""); private set
    var reply by mutableStateOf(""); private set

    private val voice = VoiceEngine(ctx)
    private val memory = MemoryStore(ctx)
    private val brain = ShipraBrain(memory)
    private val phone = PhoneController(ctx)
    private var job: Job? = null

    fun toggle() { if (job?.isActive == true) stop() else start() }

    private fun start() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            reply = "पहले माइक की परमिशन दो।"; return
        }
        job = scope.launch { loop() }
    }

    private fun stop() {
        job?.cancel(); voice.stopAll(); state = UiState.IDLE
    }

    private suspend fun loop() {
        try {
            var misses = 0
            while (currentCoroutineContext().isActive) {
                state = UiState.LISTENING
                val text = voice.listen()
                if (text.isNullOrBlank()) {
                    if (++misses >= 6) break      // बहुत देर चुप रहे तो रुक जाओ
                    delay(300); continue
                }
                misses = 0
                heard = text

                state = UiState.THINKING
                val out = withContext(Dispatchers.IO) { brain.chat(text) }
                reply = out.say

                state = UiState.SPEAKING
                voice.speak(out.say)

                for (a in out.actions) {
                    val err = phone.execute(a)
                    if (err != null) { reply = err; voice.speak(err) }
                }
            }
        } finally {
            state = UiState.IDLE
        }
    }

    fun shutdown() { job?.cancel(); voice.shutdown(); memory.close() }
}
