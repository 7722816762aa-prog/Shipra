package com.shipra.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** माइक (STT) और आवाज़ (TTS), दोनों यहाँ। कोई कीबोर्ड नहीं। */
class VoiceEngine(private val ctx: Context) {

    private val ttsReady = CompletableDeferred<Boolean>()
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("hi", "IN"))
                tts?.setPitch(1.1f)
                ttsReady.complete(true)
            } else ttsReady.complete(false)
        }
    }

    suspend fun speak(text: String) {
        if (text.isBlank() || !ttsReady.await()) return
        suspendCancellableCoroutine<Unit> { cont ->
            val id = UUID.randomUUID().toString()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (utteranceId == id && cont.isActive) cont.resume(Unit) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { if (utteranceId == id && cont.isActive) cont.resume(Unit) }
            })
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            cont.invokeOnCancellation { tts?.stop() }
        }
    }

    /** एक वाक्य सुनो। कुछ न सुनाई दे या एरर आए तो null */
    suspend fun listen(): String? = withContext(Dispatchers.Main) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return@withContext null
        suspendCancellableCoroutine<String?> { cont ->
            val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            var finished = false
            fun finish(result: String?) {
                if (finished) return
                finished = true
                rec.destroy()
                if (cont.isActive) cont.resume(result)
            }

            rec.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
                }
                override fun onError(error: Int) { finish(null) }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            cont.invokeOnCancellation { main.post { rec.destroy() } }
            rec.startListening(intent)
        }
    }

    fun stopAll() { tts?.stop() }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
