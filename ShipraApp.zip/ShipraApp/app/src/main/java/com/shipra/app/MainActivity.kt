package com.shipra.app

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {

    private lateinit var session: ShipraSession

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        session = ShipraSession(applicationContext, lifecycleScope)

        permLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_CONTACTS
            )
        )

        setContent { ShipraScreen(session) }
    }

    override fun onDestroy() {
        session.shutdown()
        super.onDestroy()
    }
}

@Composable
fun ShipraScreen(s: ShipraSession) {
    val color = when (s.state) {
        UiState.IDLE -> Color(0xFF5C5C70)
        UiState.LISTENING -> Color(0xFFE91E63)
        UiState.THINKING -> Color(0xFFFFB300)
        UiState.SPEAKING -> Color(0xFF7C4DFF)
    }
    val label = when (s.state) {
        UiState.IDLE -> "छुओ और बात शुरू करो"
        UiState.LISTENING -> "सुन रही हूँ…"
        UiState.THINKING -> "सोच रही हूँ…"
        UiState.SPEAKING -> "बोल रही हूँ…"
    }
    val pulse by rememberInfiniteTransition(label = "pulse")
        .animateFloat(1f, 1.12f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "scale")
    val orbScale = if (s.state == UiState.IDLE) 1f else pulse

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0E0E14)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("शिप्रा", color = Color.White, fontSize = 34.sp)
        Spacer(Modifier.height(40.dp))
        Box(
            modifier = Modifier.size(180.dp).scale(orbScale).clip(CircleShape)
                .background(color).clickable { s.toggle() },
            contentAlignment = Alignment.Center
        ) { Text(label, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp)) }
        Spacer(Modifier.height(40.dp))
        if (s.heard.isNotBlank()) Text("तुम: ${s.heard}", color = Color(0xFFB0B0C0), fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        if (s.reply.isNotBlank()) Text("शिप्रा: ${s.reply}", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center)
    }
}
