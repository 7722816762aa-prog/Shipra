package com.shipra.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * मॉडल के भेजे actions को असली फोन-कमांड में बदलता है।
 * हर function सफल होने पर null लौटाता है, नाकाम होने पर बोलने लायक वजह।
 */
class PhoneController(private val ctx: Context) {

    fun execute(a: JSONObject): String? = try {
        when (a.optString("type")) {
            "open_youtube" -> openYoutube(a.optString("query"))
            "call" -> call(a.optString("name"), a.optString("number"))
            "answer_call" -> answerCall()
            "end_call" -> endCall()
            "flashlight" -> torch(a.optBoolean("on", true))
            "volume" -> volume(a.optString("direction"))
            "open_settings" -> openSettings(a.optString("panel"))
            "open_app" -> openApp(a.optString("name"))
            else -> "ये वाला काम मुझे आता नहीं।"
        }
    } catch (e: SecurityException) {
        "इसकी परमिशन तुमने दी ही नहीं है।"
    } catch (e: Exception) {
        "कुछ गड़बड़ हो गई: ${e.message}"
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    // ---------- YouTube ----------
    private fun openYoutube(query: String): String? {
        if (query.isBlank()) {
            val launch = ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                ?: return "YouTube इंस्टॉल ही नहीं है।"
            start(launch); return null
        }
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        try {
            start(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube"))
        } catch (e: ActivityNotFoundException) {
            start(Intent(Intent.ACTION_VIEW, uri)) // ब्राउज़र में खुलेगा
        }
        return null
    }

    // ---------- कॉल्स ----------
    private fun call(name: String, number: String): String? {
        if (!has(Manifest.permission.CALL_PHONE)) return "कॉल की परमिशन दो पहले।"
        val num = number.filter { it.isDigit() || it == '+' }.ifBlank { findNumber(name) }
            ?: return "$name नाम का कोई नंबर मिला नहीं।"
        start(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", num, null)))
        return null
    }

    private fun findNumber(name: String): String? {
        if (name.isBlank() || !has(Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun answerCall(): String? {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "कॉल उठाने की परमिशन नहीं है।"
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        tm.acceptRingingCall()
        return null
    }

    @Suppress("DEPRECATION")
    private fun endCall(): String? {
        if (!has(Manifest.permission.ANSWER_PHONE_CALLS)) return "कॉल काटने की परमिशन नहीं है।"
        val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return if (tm.endCall()) null else "कोई चालू कॉल मिली नहीं।"
    }

    // ---------- सेटिंग्स ----------
    private fun torch(on: Boolean): String? {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "इस फोन में फ़्लैशलाइट मिली नहीं।"
        cm.setTorchMode(id, on)
        return null
    }

    private fun volume(direction: String): String? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = AudioManager.STREAM_MUSIC
        when (direction) {
            "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "max" -> am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
            else -> return "वॉल्यूम का क्या करना है, साफ़ बोलो।"
        }
        return null
    }

    private fun openSettings(panel: String): String? {
        val action = when (panel) {
            "internet", "wifi" -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            "volume" -> Settings.Panel.ACTION_VOLUME
            "nfc" -> Settings.Panel.ACTION_NFC
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action)); return null
    }

    private fun openApp(name: String): String? {
        if (name.isBlank()) return "कौन सा ऐप खोलना है?"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return "$name नाम का ऐप मिला नहीं।"
        start(pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "ऐप खुल नहीं रहा।")
        return null
    }
}
