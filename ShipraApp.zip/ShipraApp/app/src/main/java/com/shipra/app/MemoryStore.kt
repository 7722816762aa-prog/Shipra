package com.shipra.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * लॉन्ग-टर्म मेमोरी (फोन के अंदर SQLite में):
 *  - messages : पूरी बातचीत का इतिहास
 *  - facts    : "याद रखने लायक" बातें (नाम, पसंद, झगड़े, वादे...)
 */
class MemoryStore(ctx: Context) : SQLiteOpenHelper(ctx, "shipra.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, ts INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE facts(id INTEGER PRIMARY KEY AUTOINCREMENT, fact TEXT NOT NULL UNIQUE, ts INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {}

    fun addMessage(role: String, content: String) {
        val cv = ContentValues().apply {
            put("role", role); put("content", content); put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("messages", null, cv)
    }

    /** पिछले n मैसेज, पुराने से नए क्रम में; हमेशा "user" से शुरू (API की शर्त) */
    fun recentMessages(n: Int): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", arrayOf(n.toString())).use {
            while (it.moveToNext()) out.add(it.getString(0) to it.getString(1))
        }
        out.reverse()
        while (out.isNotEmpty() && out.first().first != "user") out.removeAt(0)
        return out
    }

    fun addFact(fact: String) {
        val f = fact.trim()
        if (f.isEmpty()) return
        val cv = ContentValues().apply { put("fact", f); put("ts", System.currentTimeMillis()) }
        writableDatabase.insertWithOnConflict("facts", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun allFacts(limit: Int = 80): List<String> {
        val out = ArrayList<String>()
        readableDatabase.rawQuery("SELECT fact FROM facts ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use {
            while (it.moveToNext()) out.add(it.getString(0))
        }
        return out.reversed()
    }

    /** पुरानी बातचीत में से मिलते-जुलते शब्दों वाली लाइनें खोजो (सरल keyword search) */
    fun search(text: String, max: Int = 6): List<String> {
        val words = text.split(Regex("\\s+")).map { it.trim('?', '!', '.', ',', '।') }.filter { it.length >= 4 }.take(5)
        val found = LinkedHashSet<String>()
        for (w in words) {
            readableDatabase.rawQuery(
                "SELECT role, content FROM messages WHERE content LIKE ? ORDER BY id DESC LIMIT 3",
                arrayOf("%$w%")
            ).use { while (it.moveToNext()) found.add("${if (it.getString(0) == "user") "तुम" else "मैं"}: ${it.getString(1)}") }
            if (found.size >= max) break
        }
        return found.take(max)
    }

    fun forgetEverything() {
        writableDatabase.execSQL("DELETE FROM messages")
        writableDatabase.execSQL("DELETE FROM facts")
    }
}
