# Shipra: वॉयस-ओनली Android साथी

## स्ट्रक्चर
```
ShipraApp/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── local.properties.example      ← इसे local.properties बनाओ, API key डालो
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/shipra/app/
            ├── MainActivity.kt     UI (सिर्फ़ एक बड़ा माइक-ऑर्ब, कोई कीबोर्ड नहीं)
            ├── ShipraSession.kt    सुनो → सोचो → बोलो → काम करो का लूप
            ├── VoiceEngine.kt      SpeechRecognizer (STT) + TextToSpeech (TTS), हिंदी
            ├── ShipraBrain.kt      Anthropic API कॉल + जवाब का JSON पार्स
            ├── Persona.kt          शिप्रा का किरदार + actions की सूची (system prompt)
            ├── MemoryStore.kt      SQLite लॉन्ग-टर्म मेमोरी (messages + facts + search)
            └── PhoneController.kt  YouTube, कॉल, वॉल्यूम, टॉर्च, सेटिंग्स, ऐप खोलना
```

## APK कैसे बनाएँ
1. Android Studio (Koala या नया) में `ShipraApp` फ़ोल्डर खोलो।
2. `local.properties.example` को `local.properties` नाम से कॉपी करो, `sdk.dir` और `ANTHROPIC_API_KEY` भरो।
3. Build > Build Bundle(s) / APK(s) > Build APK(s)। या टर्मिनल से: `./gradlew assembleDebug`
4. APK मिलेगा: `app/build/outputs/apk/debug/app-debug.apk`। फोन पर इंस्टॉल करो।
5. पहली बार खोलने पर माइक, कॉल, कॉन्टैक्ट्स की परमिशन दो।

## जो सच में काम करेगा / जो नहीं
- काम करेगा: बोलकर बात, मेमोरी (ऐप बंद करके भी), "रोहन को कॉल करो", "कॉल उठा लो / काट दो", "YouTube पर ... चलाओ", वॉल्यूम, टॉर्च, सेटिंग्स पैनल, ऐप खोलना।
- Wi-Fi/Bluetooth को चुपचाप ON/OFF करना Android 10+ में थर्ड-पार्टी ऐप के लिए बंद है, इसलिए सेटिंग्स पैनल खुलेगा।
- कॉल के दौरान शिप्रा की आवाज़ कॉल में डालना या कॉल की आवाज़ सुनना Android थर्ड-पार्टी ऐप को नहीं देता। इसलिए "कॉल पर बात करना" संभव नहीं।
- YouTube खुलते ही ऐप बैकग्राउंड में चला जाता है और Android बैकग्राउंड में माइक बंद कर देता है। ऐप पर लौटकर बात करनी होगी। इसका हल एक Foreground Service (type: microphone) है, जो अगला कदम है।
- कॉन्टैक्ट नाम अंग्रेज़ी में सेव हैं तो हिंदी बोलने पर मैच न हो, तब नंबर बोलो या नाम अंग्रेज़ी में बोलो।

## प्राइवेसी / सुरक्षा
- API key BuildConfig के ज़रिए APK में जाती है। सिर्फ़ अपने निजी इस्तेमाल के लिए ठीक है, APK किसी को बाँटना या Play Store पर डालना हो तो बीच में अपना सर्वर रखो।
- तुम्हारी आवाज़ फोन के Google स्पीच-रिकग्निशन सर्विस से टेक्स्ट बनती है, और वो टेक्स्ट, याद रखी बातों के साथ, Anthropic API को जाता है। मेमोरी सिर्फ़ फोन के SQLite में रहती है।
- `MemoryStore.forgetEverything()` से सब मिटाया जा सकता है।
